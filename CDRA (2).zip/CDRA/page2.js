var help1 = document.getElementById("help1");
var help2 = document.getElementById("help2");
var help3 = document.getElementById("help3");
var help4 = document.getElementById("help4");
var help5 = document.getElementById("help5");
var help_title = document.getElementById("help-title")
var help_answer = document.getElementById("help-answer");
var choices = document.getElementById("choices");

var helps = [
    {
        help_id: help1.value,
        help: "We would contact you in few minutes via your email regarding the request above. Thank You"
    },
    {
        help_id: help2.value,
        help: "We would contact you in few minutes via your email regarding the request above. Thank You"
    },
    {
        help_id: help3.value,
        help: "We would contact you in few minutes via your email regarding the request above. Thank You"
    },
    {
        help_id: help4.value,
        help: "We would contact you in few minutes via your email regarding the request above. Thank You"
    },
	
	{
        help_id: help5.value,
        help: "We would contact you in few minutes via your email regarding the request above. Thank You"
    },
]

function getSelectedOption(choice) {
    // if (help1.value == "Help 1") {
    //     help_title.innerHTML = helps[0].help_id;
    //     help_answer.innerHTML = helps[0].help;
    // }
    // if (help2.value == "Help 2") {
    //     help_title.innerHTML = helps[1].help_id;
    //     help_answer.innerHTML = helps[1].help;
    // }
    // if (help3.value == "Help 3") {
    //     help_title.innerHTML = helps[2].help_id;
    //     help_answer.innerHTML = helps[2].help;
    // }
    // if (help4.value == "Help 4") {
    //     help_title.innerHTML = helps[3].help_id;
    //     help_answer.innerHTML = helps[3].help;
    // }

    var option1 = choice.options[1];
    var option2 = choice.options[2];
    var option3 = choice.options[3];
    var option4 = choice.options[4];
	var option5 = choice.options[5];
    // for (var i = 0, len=choices.options.length; i < len; i++) {
    //     option = choices.options[i];
    //     if (option.selected === true)
    // }

    if (option1.selected === true) {
        help_title.innerHTML = helps[0].help_id;
        help_answer.innerHTML = helps[0].help;
    } else if (option2.selected === true) {
        help_title.innerHTML = helps[1].help_id;
        help_answer.innerHTML = helps[1].help;
    } else if (option3.selected === true) {
        help_title.innerHTML = helps[2].help_id;
        help_answer.innerHTML = helps[2].help;
    } else if (option4.selected === true) {
        help_title.innerHTML = helps[3].help_id;
        help_answer.innerHTML = helps[3].help;
    } 
	
	 else if (option5.selected === true) {
        help_title.innerHTML = helps[4].help_id;
        help_answer.innerHTML = helps[4].help;
    } 
}

document.getElementById("Button1").addEventListener("click", 
    function (event) {
        getSelectedOption(choices);
    }
    )